function x = sine(duration, fs)
% sine: returns a matrix representing a sine wave
% Author: Ann Truong

% amplitude is amplitude of wave
% freq is frequency of wave
% phase shift is given in periods
% fs is sampling frequency (ie how many points we look at per second)
% duration is time in seconds
% duty is on/off time (not applicable to sinusoids, but included for 
%   uniformity w other wave generating functions)

    
    Length = fs.Value * duration.Value; % length of matrix
    %fsValue = fs.Value
    %durationValue = duration.Value 
    wave = (1:Length); % Sine Wave
    T = 1/fs.Value; % sampling period, the time between two entries in matrix

    % generates a 1D matrix w specified length and # of entries
    % wave = linspace(0, Length, fs.Value);
   
    % populates the matrix we just made. you can think of this matrix as a
    % table, where each entry is the y-value that corresponds to x*i on the
    % x-axis. since the x-axis is evenly spaced, we leave out that info.
    for i = 1:Length
        t = T*i; % this is the time at each point
        wave(i) = sin(2*pi*t);
    end
    %SINE = length(wave)
    
    x = wave;
end