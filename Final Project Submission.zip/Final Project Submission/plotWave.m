function t = plotWave(fs)
global waveToPlot
figure(1)
N = length(waveToPlot);
t = (1:N)/fs.Value;
%t = linspace(0, sldDuration.Value*fs.Value, sldDuration.Value);
    plot(t, waveToPlot);
    xlabel("Time");
    ylabel("Amplitude");
    
end