function x = square(amplitude, fs, duration, adjustment)
% square: generates a square wave
% Author: Rebecca Wong

% amplitude is amplitude of wave
% freq is frequency of wave
% phase shift is given in periods
% fs is sampling frequeney (points per second)
% duration is time in seconds
% duty controls on/off time; 
%   it is the percentage of a waveform that occurs above the zero axis (+amplitude)
%   duty of 0.5 will return a propper square wave (equal time at + and - amplitude)

%    duty = 0.5;

%    length = fs.Value * duration.Value + 1; % length of matrix
%    T = 1/fs.Value; % period 
%    x = zeros(1, length); % generates matrix of size 1 by length
%    
%    for i = 1:n
%        t = i*T; % exact time of point
%    
%        st = mod(freq * t, 1); % remainder after dividing by 1
%    
%        if(st < duty)
%            x(i) = amplitude.Value;
%        else
%            x(i) = -amplitude.Value;
%        end
%    end
    
    length = fs.Value * duration.Value;
    x3 = (1:length); % Square Wave
    adjustmentValue = 10*adjustment.Value;
    
    for B = 1:length
        a = 0;
            for k = 1:(2*adjustmentValue)
                k2 = 2*k - 1;
                a = a + sin(k2*pi*B/500)/k2;
            end
        x3(B) = (a*2/pi + 0.5)*amplitude.Value;
    end
    x = x3;
end